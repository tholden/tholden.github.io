close all;
clear variables;

Path = which( 'autocorr.m' );
Text = readlines( Path );
Text = regexprep( Text, 'y\s*=\s*y\s*-\s*mean\(\s*y.*?\);', '' );
writelines( Text, 'autocorrNoMean.m' );

gcp;

% PCE to CPI conversion.

Data = readtable( 'RealTimeCPI.xlsx', 'Sheet', 'Data', 'Range', 'A102:D356' );

% Get initial values using a ridge regression approach.

Dates = Data{ :, 1 };
CPI = Data{ :, 3 };
PCE = Data{ :, 4 };
T = size( Data, 1 );
Triangle = tril( ones( T ) );

XPoints = [ Triangle, 6 * diag( PCE ) * Triangle ].'; % 6 = 12 (months in a year) / 2 (the inflation target)

[ YQueryPoints, BestGCVObjective, BetaHat, Lambda, PenaltyScale ] = GCVRidgeRegression( XPoints, CPI.' - PCE.', XPoints, struct( 'Demean', false, 'Rescale', false, 'Debug', false, 'Verbosity', 10 ) );

alpha = cumsum( BetaHat( 1 : T ) );
beta = 1 + cumsum( 6 * BetaHat( ( T + 1 ) : end ) );

Predicted = alpha + beta .* PCE;
AltPredicted = YQueryPoints.' + PCE;

disp( 'Max error from alternative representation:' );
disp( max( abs( Predicted - AltPredicted ) ) );

Residuals = CPI - Predicted;

Model = ssm( eye( 2 ), diag( NaN( 2, 1 ) ), arrayfun( @( t ) [ 1, PCE( t ) ], 1 : T, 'UniformOutput', false ), NaN, 'Mean0', [ 0; 2 / 12 ], 'Cov0', diag( [ 1, 12 / 2 ] .^ 2 ), 'StateType', [ 2; 2 ] );

OriginalParameters = [ std( diff( alpha ) ); std( diff( beta ) ); std( Residuals ) ];

[ EstimatedModel, EstimatedParameters ] = estimate( Model, CPI, OriginalParameters, 'CovMethod', 'sandwich', 'Display', 'full', 'SquareRoot', true, 'Options', optimoptions( 'fminunc', 'Algorithm', 'quasi-newton', 'Display', 'iter-detailed', 'FiniteDifferenceType', 'central', 'MaxFunctionEvaluations', 1e12, 'MaxIterations', 1e12, 'OptimalityTolerance', 1e-12, 'StepTolerance', 1e-12, 'UseParallel', true ) );

disp( 'Initial and final parameters:' )
disp( [ OriginalParameters, EstimatedParameters ] );

alpha_beta = smooth( EstimatedModel, CPI, 'SquareRoot', true );

alpha = alpha_beta( :, 1 );
beta = alpha_beta( :, 2 );

Predicted = alpha + beta .* PCE;

stdPCE = std( PCE );
beta_stdPCE = beta * stdPCE;
rho_PCE_CPI = beta_stdPCE ./ sqrt( beta_stdPCE .* beta_stdPCE + EstimatedParameters( 3 ) ^ 2 );

Residuals = CPI - Predicted;

figure;
plot( Dates, CPI, Dates, Predicted );
figure;
plot( Dates, Residuals );
figure;
plot( Dates, alpha, 'k' );
xlabel( 'Year' );
ylabel( '$\alpha_t$', 'Interpreter', 'latex' );
saveas( gcf, 'alpha.svg' );
figure;
plot( Dates, beta, 'k' );
xlabel( 'Year' );
ylabel( '$\beta_t$', 'Interpreter', 'latex' );
saveas( gcf, 'beta.svg' );
figure;
plot( Dates, rho_PCE_CPI, 'k' );
xlabel( 'Year' );
ylabel( 'Implied correlation between PCE and CPI inflation' );
saveas( gcf, 'rho_PCE_CPI.svg' );

ABDates = Dates + calendarDuration( 0, 1, 0 ); % ABDates has the month at which this is observed.

writetable( table( ABDates, alpha, beta ), 'EstimatedAlphaBeta.xlsx', 'WriteMode', 'replacefile' );

clearvars -except ABDates alpha beta;

% Model for PiStar

warning( 'off', 'MATLAB:table:ModifiedAndSavedVarnames' );
Data = readtable( 'EstimatingTheta.xlsx', 'Sheet', 'Data', 'Range', 'B1:AU197', 'ReadVariableNames', true, 'VariableNamingRule', 'modify' );
warning( 'on', 'MATLAB:table:ModifiedAndSavedVarnames' );

T = size( Data, 1 );

Dates = Data{ :, 1 };
PiObs = Data.CPI;
PiStarInfinityObs = 100 * log( 1 + Data.Infinity / 12 / 100 );
PiStarAnnualObs = 100 * log( 1 + Data{ :, end - 40 : end - 1 } / 100 );

FirstIndexIntoABDates = find( Dates( 1 ) == ABDates );
IndicesIntoABDates = FirstIndexIntoABDates : ( FirstIndexIntoABDates + T - 1 );
assert( all( ABDates( IndicesIntoABDates ) == Dates ) );

PiStarAnnualObs = 12 * alpha( IndicesIntoABDates ) + beta( IndicesIntoABDates ) .* PiStarAnnualObs;
PiStarInfinityObs = alpha( IndicesIntoABDates ) + beta( IndicesIntoABDates ) .* PiStarInfinityObs;

Model = arima( 1, 0, 1 );

EstimatedModel = estimate( Model, PiObs, 'AR0', 0.9, 'MA0', -0.8, 'Display', 'full', 'Options', optimoptions( 'fmincon', 'ConstraintTolerance', 1e-12, 'Display', 'iter-detailed', 'FiniteDifferenceType', 'central', 'MaxFunctionEvaluations', 1e12, 'MaxIterations', 1e12, 'OptimalityTolerance', 1e-12, 'StepTolerance', 1e-12, 'FunctionTolerance', 1e-12, 'UseParallel', true ) );

AR = EstimatedModel.AR{ 1 };
MA = EstimatedModel.MA{ 1 };
Sigma = sqrt( EstimatedModel.Variance );

LogitAR = log( 1 + AR ) - log( 1 - AR );

OriginalParameters = [ LogitAR; LogitAR; MA * Sigma / 2; MA * Sigma / 2; log( Sigma / 2 ); log( Sigma / 2 ); -5; -5 ];

Model = ssm( @ParameterFunction );

Data = [ PiStarAnnualObs, PiObs, PiStarInfinityObs ];

[ EstimatedModel, EstimatedParameters, EstimatedParametersCovariance ] = estimate( Model, Data, OriginalParameters, 'CovMethod', 'sandwich', 'Display', 'full', 'SquareRoot', true, 'Options', optimoptions( 'fminunc', 'Algorithm', 'quasi-newton', 'Display', 'iter-detailed', 'FiniteDifferenceType', 'central', 'MaxFunctionEvaluations', 1e12, 'MaxIterations', 1e12, 'OptimalityTolerance', 1e-12, 'StepTolerance', 1e-12, 'UseParallel', true ) );

disp( 'Initial and final parameters:' )
disp( [ OriginalParameters, EstimatedParameters ] );

NaturalDomainParameters = [ 2 ./ ( 1 + exp( -EstimatedParameters( 1 : 2 ) ) ) - 1; EstimatedParameters( 3 : 4 ); exp( EstimatedParameters( 5 : 8 ) ) ];
DNaturalDomainParameters = [ 2 .* exp( -EstimatedParameters( 1 : 2 ) ) ./ ( 1 + exp( -EstimatedParameters( 1 : 2 ) ) ) .^ 2; ones( 2, 1 ); exp( EstimatedParameters( 5 : 8 ) ) ];
disp( 'Final parameters in natural domain, with their delta method standard error:' );
disp( [ NaturalDomainParameters, sqrt( diag( EstimatedParametersCovariance ) ) .* abs( DNaturalDomainParameters ) ] );


[ SmoothedState, ~, SmoothingOutput ] = smooth( EstimatedModel, Data, 'SquareRoot', true );

Pi = SmoothedState( :, 14 );
PiStar = SmoothedState( :, 15 );
VarPiStar = arrayfun( @( t ) SmoothingOutput( t ).SmoothedStatesCov( 15, 15 ), 1 : T, 'UniformOutput', true ).';
StdPiStar = sqrt( VarPiStar );

FillBetweenLines = @( X, Y1, Y2 ) fill( [ X(:).', flip( X(:) ).' ],  [ Y1(:).', flip( Y2(:) ).' ], [ 0.8, 0.8, 0.8 ], 'EdgeColor', 'none', 'LineStyle', 'none' );

figure;
FillBetweenLines( Dates, 12 * ( PiStar - norminv( 0.95 ) * StdPiStar ), 12 * ( PiStar + norminv( 0.95 ) * StdPiStar ) ); % 90% confidence bands.
hold on;
plot( Dates, 12 * Pi, 'k--', Dates, 12 * PiStar, 'k' );
xlabel( 'Year' );
ylabel( 'Annualized inflation rate' );
saveas( gcf, 'MonthlyPiPiStar.svg' );




[ A, B, C, D, Mean0 ] = ParameterFunction( EstimatedParameters );

FiveYearExpectation = SmoothedState( :, 16 ) + SmoothedState( :, 15 ); % Expectation at t of pi^*_{t-1} + pi^*_{t} +...

ForwardState = SmoothedState;

for t = 1 : ( 5 * 12 - 2 )
    ForwardState = ForwardState * A.';
    FiveYearExpectation = FiveYearExpectation + ForwardState( :, 15 );
end

FiveYearExpectation = FiveYearExpectation / 5;

warning( 'off', 'MATLAB:table:ModifiedAndSavedVarnames' );
Data = readtable( 'EstimatingTheta.xlsx', 'Sheet', 'BreakEvenInflationData', 'Range', 'A11:C255', 'ReadVariableNames', true, 'VariableNamingRule', 'modify' );
warning( 'on', 'MATLAB:table:ModifiedAndSavedVarnames' );

BreakevenInflation = Data.BreakevenInflation( ismember( Data.observation_date, Dates ) );

warning( 'off', 'MATLAB:table:ModifiedAndSavedVarnames' );
Data = readtable( 'OilSupplyNewsShocksKaenzig.xlsx', 'Sheet', 'Monthly', 'Range', 'D1:F577', 'ReadVariableNames', true, 'VariableNamingRule', 'modify' );
warning( 'on', 'MATLAB:table:ModifiedAndSavedVarnames' );

OilSupplyNewsShock = Data.OilSupplyNewsShock( ismember( Data.Date, Dates ) );

warning( 'off', 'MATLAB:table:ModifiedAndSavedVarnames' );
Data = readtable( 'TreasuryYields.xlsx', 'Sheet', 'FRED Graph', 'Range', 'A11:B853', 'ReadVariableNames', true, 'VariableNamingRule', 'modify' );
warning( 'on', 'MATLAB:table:ModifiedAndSavedVarnames' );

TreasuryYield = Data.GS5( ismember( Data.observation_date, Dates ) );

% Now convert to quarterly.

AggregationVector = [ 1; 1; 1 ];

PiStar = SmoothedState( :, 15 : 17 ) * AggregationVector;

VarPiStar = arrayfun( @( t ) AggregationVector.' * SmoothingOutput( t ).SmoothedStatesCov( 15 : 17, 15 : 17 ) * AggregationVector, 1 : T, 'UniformOutput', true ).';

StdPiStar = sqrt( VarPiStar );

                % VarObsRelativeInflation = arrayfun( @( t ) [ 12 -12 ] * SmoothingOutput( t ).SmoothedStatesCov( [ 14, 15 ], [ 14, 15 ] ) * [ 12; -12 ], 1 : T, 'UniformOutput', true ).';
                % VarObsRelativeInflation = [ NaN; VarObsRelativeInflation( 1 : ( end - 1 ) ) ];
                % VarRelativeInflation = [ 12 -12 ] * EstimatedModel.Cov0( [ 14, 15 ], [ 14, 15 ] ) * [ 12; -12 ];
                % LambdaRelativeInflation = VarRelativeInflation ./ ( VarRelativeInflation + VarObsRelativeInflation );

QuarterlySums = @( z ) [ z, [ NaN; z( 1 : ( end - 1 ) ) ], [ NaN; NaN; z( 1 : ( end - 2 ) ) ] ] * AggregationVector;

Pi = QuarterlySums( Pi );
OilSupplyNewsShock = QuarterlySums( OilSupplyNewsShock );

Dates = Dates( 11 : 3 : end ) + calendarDuration( 0, 0, 14 );

PiLong = Pi( 9 : 3 : end );
Pi = Pi( 12 : 3 : end ); % First element is Q4.
OilSupplyNewsShock = OilSupplyNewsShock( 12 : 3 : end );
DPiStar = diff( PiStar( 9 : 3 : end ) );
PiStarLong = PiStar( 9 : 3 : end );
PiStar = PiStar( 12 : 3 : end );
StdPiStar = StdPiStar( 12 : 3 : end );

FiveYearExpectation = FiveYearExpectation( 8 : 3 : end );
BreakevenInflation = BreakevenInflation( 9 : 3 : end );
TreasuryYield = TreasuryYield( 9 : 3 : end );

figure;
FillBetweenLines( Dates, 4 * ( PiStar - norminv( 0.95 ) * StdPiStar ), 4 * ( PiStar + norminv( 0.95 ) * StdPiStar ) ); % 90% confidence bands.
hold on;
plot( Dates, 4 * Pi, 'k--', Dates, 4 * PiStar, 'k' );
xlabel( 'Year' );
ylabel( 'Annualized inflation rate' );
saveas( gcf, 'PiPiStar.svg' );

figure;
plot( Dates, BreakevenInflation( 2 : end ), 'k--', Dates, FiveYearExpectation( 2 : end ), 'k' );
xlabel( 'Year' );
ylabel( 'Average annual inflation rate' );
saveas( gcf, 'FiveYearExpectation.svg' );

save Results ABDates alpha beta Dates PiStar FiveYearExpectation;

writetable( table( Dates, PiStar, FiveYearExpectation( 2 : end ) ), 'EstimatedPiStarAndFiveYearExpectation.xlsx', 'WriteMode', 'replacefile' );

RelativeFiveYearExpectation = BreakevenInflation - FiveYearExpectation;

x = Pi - PiStar;
xLong = PiLong - PiStarLong;
z = OilSupplyNewsShock;
y = 0.25 * ( RelativeFiveYearExpectation( 2 : end ) - RelativeFiveYearExpectation( 1 : ( end - 1 ) ) );
f = 0.25 * RelativeFiveYearExpectation - xLong / 20;
yMod = f( 2 : end ) - f( 1 : ( end - 1 ) );

yA = 0.25 * RelativeFiveYearExpectation( 2 : end );
yB = 0.25 * ( BreakevenInflation( 2 : end ) - BreakevenInflation( 1 : ( end - 1 ) ) );
yC = 0.25 * BreakevenInflation( 2 : end );
yD = 0.25 * ( TreasuryYield( 2 : end ) - TreasuryYield( 1 : ( end - 1 ) ) );
yE = 0.25 * TreasuryYield( 2 : end );

% Drop the first year to give the smoother time to "burn-in"
x( 1 : 4 ) = [];
y( 1 : 4 ) = [];
z( 1 : 4 ) = [];
yMod( 1 : 4 ) = [];
yA( 1 : 4 ) = [];
yB( 1 : 4 ) = [];
yC( 1 : 4 ) = [];
yD( 1 : 4 ) = [];
yE( 1 : 4 ) = [];
Dates( 1 : 4 ) = [];

% Drop the 2023Q1 observation as the news shock series doesn't go so far.
x( end ) = [];
y( end ) = [];
yMod( end ) = [];
yA( end ) = [];
yB( end ) = [];
yC( end ) = [];
yD( end ) = [];
yE( end ) = [];
Dates( end ) = [];

Years = unique( year( Dates ) );

% Quarterly version

Labels = repmat( Years(:).', 4, 1 );
Labels = cellstr( [ num2str( Labels(:) ) repmat( [ repmat( 'Q', 4, 1 ) num2str( ( 1 : 4 ).' ) ], numel( Years ), 1 ) ] );
Labels( 1 : 3 ) = [];
% Labels( ( end - 2 ) : end ) = [];

assert( size( Labels, 1 ) == numel( y ) );

% [ ~, SEtheta, theta ] = hac( X, y, 'Intercept', false, 'Whiten', 1, 'Weights', 'PZ' );
% Ptheta = 2 * ( 1 - tcdf( theta / SEtheta, size( y, 1 ) - 1 ) );

[ theta, ~, ~, Ptheta ] = hacIV( x, x, y );
[ thetaMod, ~, ~, PthetaMod ] = hacIV( x, x, yMod );

[ thetaIV, ~, ~, PthetaIV, ~, ~, ~, ~, F ] = hacIV( x, z, y );
[ ~, ~, ~, PthetaIV01 ] = hacIV( x, z, y - 0.1 * x );
[ thetaIVMod, ~, ~, PthetaIVMod, ~, ~, ~, ~, FMod ] = hacIV( x, z, yMod );

figure;
autocorrNoMean( yMod );
figure;
autocorrNoMean( x );

resid = y - x * theta;
residIV = y - x * thetaIV;
residMod = yMod - x * thetaMod;
residIVMod = yMod - x * thetaIVMod;


% Now the approach using a monetary shock instrument

MS = readmatrix( 'FOMC_Bauer_Swanson.xlsx', 'Sheet', 'Monthly SVAR Data', 'Range', 'I431:I565' ); % I419 I431
LastMS = numel( MS ) / 3;
MS = sum( reshape( MS, 3, LastMS ) ).';

figure; plot( 1 : LastMS, residIV( 1 : LastMS ), 'k', 1 : LastMS, MS, 'r' );
figure; plot( 1 : LastMS, residIVMod( 1 : LastMS ), 'k', 1 : LastMS, MS, 'r' );

FirstMS = 1;

MS = MS( FirstMS : LastMS );
xMS = x( FirstMS : LastMS, : );
yMS = y( FirstMS : LastMS );
yMSMod = yMod( FirstMS : LastMS );

NMS = numel( MS );

XMS = [ xMS, yMS ];
XMSMod = [ xMS, yMSMod ];

[ ab, var_ab ] = hacIV( XMS, XMS, MS );

thetaMS = -ab( 1 ) / ab( 2 );

Grad = [ -1 / ab( 2 ); ab( 1 ) / ( ab( 2 ) * ab( 2 ) ) ];

var_thetaMS = Grad.' * var_ab * Grad;

t_thetaMS = thetaMS ./ sqrt( var_thetaMS );

PthetaMS = 2 * ( 1 - tcdf( abs( t_thetaMS ), NMS - 2 ) );


[ ab, var_ab ] = hacIV( XMSMod, XMSMod, MS );

thetaMSMod = -ab( 1 ) / ab( 2 );

Grad = [ -1 / ab( 2 ); ab( 1 ) / ( ab( 2 ) * ab( 2 ) ) ];

var_thetaMSMod = Grad.' * var_ab * Grad;

t_thetaMSMod = thetaMSMod ./ sqrt( var_thetaMSMod );

PthetaMSMod = 2 * ( 1 - tcdf( abs( t_thetaMSMod ), NMS - 2 ) );


residMS = y - x * thetaMS;
residMSMod = yMod - x * thetaMSMod;

RSS = sum( resid .^ 2 );
RSSIV = sum( residIV .^ 2 );
RSSMS = sum( residMS .^ 2 );
RSSMod = sum( residMod .^ 2 );
RSSIVMod = sum( residIVMod .^ 2 );
RSSMSMod = sum( residMSMod .^ 2 );

disp( 'Results from the unmodified quarterly exercise:' );
disp( 'Correlation of y with z, p-value below:' );
disp( corrNoMean( y, z ) );
disp( 'Estimated theta from the quarterly exercise (OLS, IV, MS):' );
disp( [ theta thetaIV thetaMS ] );
disp( 'HAC P-value from the quarterly exercise (OLS, IV, MS):' );
disp( [ Ptheta PthetaIV PthetaMS ] );
disp( 'HAC P-value of theta=0.1 from the quarterly exercise (IV, MS):' );
disp( PthetaIV01 );
disp( 'First stage IV F value from the quarterly exercise:' );
disp( F );
disp( 'Correlation of residuals with the Bauer Swanson monetary shocks (OLS, IV, MS), p-values below:' );
disp( [ corrNoMean( resid( FirstMS : LastMS ), MS ), corrNoMean( residIV( FirstMS : LastMS ), MS ), corrNoMean( residMS( FirstMS : LastMS ), MS ) ] );
disp( 'Spearman correlation of residuals with the Bauer Swanson monetary shocks (OLS, IV, MS):' );
disp( [ corr( resid( FirstMS : LastMS ), MS, 'Type', 'Spearman' ), corr( residIV( FirstMS : LastMS ), MS, 'Type', 'Spearman' ), corr( residMS( FirstMS : LastMS ), MS, 'Type', 'Spearman' ) ] );
disp( 'R^2 of changes in relative breakeven inflation from the quarterly exercise (OLS, IV, MS):' );
disp( [ 1 - RSS ./ sum( y .* y ), 1 - RSSIV ./ sum( y .* y ), 1 - RSSMS ./ sum( y .* y ) ] );
disp( 'R^2 of relative breakeven inflation from the quarterly exercise (OLS, IV, MS):' );
disp( [ 1 - RSS ./ sum( yA .* yA ), 1 - RSSIV ./ sum( yA .* yA ), 1 - RSSMS ./ sum( yA .* yA ) ] );
disp( 'R^2 of changes in breakeven inflation from the quarterly exercise (OLS, IV, MS):' );
disp( [ 1 - RSS ./ sum( yB .* yB ), 1 - RSSIV ./ sum( yB .* yB ), 1 - RSSMS ./ sum( yB .* yB ) ] );
disp( 'R^2 of breakeven inflation from the quarterly exercise (OLS, IV, MS):' );
disp( [ 1 - RSS ./ sum( yC .* yC ), 1 - RSSIV ./ sum( yC .* yC ), 1 - RSSMS ./ sum( yC .* yC ) ] );
disp( 'R^2 of changes in yields from the quarterly exercise (OLS, IV, MS):' );
disp( [ 1 - RSS ./ sum( yD .* yD ), 1 - RSSIV ./ sum( yD .* yD ), 1 - RSSMS ./ sum( yD .* yD ) ] );
disp( 'R^2 of yields from the quarterly exercise (OLS, IV, MS):' );
disp( [ 1 - RSS ./ sum( yE .* yE ), 1 - RSSIV ./ sum( yE .* yE ), 1 - RSSMS ./ sum( yE .* yE ) ] );

disp( 'Results from the modified quarterly exercise:' );
disp( 'Correlation of yMod with z, p-value below:' );
disp( corrNoMean( yMod, z ) );
disp( 'Estimated thetaMod from the quarterly exercise (OLS, IV, MS):' );
disp( [ thetaMod thetaIVMod thetaMSMod ] );
disp( 'HAC P-value from the quarterly exercise (OLS, IV, MS):' );
disp( [ PthetaMod PthetaIVMod PthetaMSMod ] );
disp( 'First stage IV F value from the quarterly exercise:' );
disp( FMod );
disp( 'Correlation of residuals with the Bauer Swanson monetary shocks (OLS, IV, MS), p-values below:' );
disp( [ corrNoMean( residMod( FirstMS : LastMS ), MS ), corrNoMean( residIVMod( FirstMS : LastMS ), MS ), corrNoMean( residMSMod( FirstMS : LastMS ), MS ) ] );
disp( 'Spearman correlation of residuals with the Bauer Swanson monetary shocks (OLS, IV, MS):' );
disp( [ corr( residMod( FirstMS : LastMS ), MS, 'Type', 'Spearman' ), corr( residIVMod( FirstMS : LastMS ), MS, 'Type', 'Spearman' ), corr( residMSMod( FirstMS : LastMS ), MS, 'Type', 'Spearman' ) ] );
disp( 'R^2 of changes in modified relative breakeven inflation from the quarterly exercise (OLS, IV, MS):' );
disp( [ 1 - RSSMod ./ sum( yMod .* yMod ), 1 - RSSIVMod ./ sum( yMod .* yMod ), 1 - RSSMSMod ./ sum( yMod .* yMod ) ] );
disp( 'R^2 of changes in relative breakeven inflation from the quarterly exercise (OLS, IV, MS):' );
disp( [ 1 - RSSMod ./ sum( y .* y ), 1 - RSSIVMod ./ sum( y .* y ), 1 - RSSMSMod ./ sum( y .* y ) ] );
disp( 'R^2 of relative breakeven inflation from the quarterly exercise (OLS, IV, MS):' );
disp( [ 1 - RSSMod ./ sum( yA .* yA ), 1 - RSSIVMod ./ sum( yA .* yA ), 1 - RSSMSMod ./ sum( yA .* yA ) ] );
disp( 'R^2 of changes in breakeven inflation from the quarterly exercise (OLS, IV, MS):' );
disp( [ 1 - RSSMod ./ sum( yB .* yB ), 1 - RSSIVMod ./ sum( yB .* yB ), 1 - RSSMSMod ./ sum( yB .* yB ) ] );
disp( 'R^2 of breakeven inflation from the quarterly exercise (OLS, IV, MS):' );
disp( [ 1 - RSSMod ./ sum( yC .* yC ), 1 - RSSIVMod ./ sum( yC .* yC ), 1 - RSSMSMod ./ sum( yC .* yC ) ] );
disp( 'R^2 of changes in yields from the quarterly exercise (OLS, IV, MS):' );
disp( [ 1 - RSSMod ./ sum( yD .* yD ), 1 - RSSIVMod ./ sum( yD .* yD ), 1 - RSSMSMod ./ sum( yD .* yD ) ] );
disp( 'R^2 of yields from the quarterly exercise (OLS, IV, MS):' );
disp( [ 1 - RSSMod ./ sum( yE .* yE ), 1 - RSSIVMod ./ sum( yE .* yE ), 1 - RSSMSMod ./ sum( yE .* yE ) ] );

figure;
scatter( 4 * x, 4 * y, 12, 'filled', 'k' );
hold on;
XLim = xlim;
YLim = ylim;
plot( XLim, XLim * theta, 'k:', 'LineWidth', 1 );
plot( XLim, XLim * thetaIV, 'k-', 'LineWidth', 1 );
plot( XLim, XLim * thetaMS, 'k--', 'LineWidth', 1 );
OnLeft = ismember( Labels, { '2008Q4', '2011Q4', '2012Q4', '2021Q1', '2020Q2', '2022Q1' } ); % '2022Q4', '2023Q1'
OnRight = ismember( Labels, { '2009Q1', '2009Q3', '2009Q4', '2015Q2', '2020Q1', '2021Q2', '2022Q2' } ); % '2008Q3', 
text( 4 * x( OnRight ) + 4 * 0.05, 4 * y( OnRight ), Labels( OnRight ), 'HorizontalAlignment', 'left', 'VerticalAlignment', 'middle' );
text( 4 * x( OnLeft ) - 4 * 0.05, 4 * y( OnLeft ), Labels( OnLeft ), 'HorizontalAlignment', 'right', 'VerticalAlignment', 'middle' );
xlim( XLim );
ylim( YLim );
% xlabel( '$x_t=\pi_t-\pi_t^*$ \textsf{(continuously-compounded annual rate)}', 'Interpreter', 'latex' );
% ylabel( '$y_t$ \textsf{(continuously-compounded annual rate)}', 'Interpreter', 'latex' );
set( gca, 'Box', 'on' );
saveas( gcf, 'Quarterly.svg' );

figure;
scatter( 4 * x, 4 * yMod, 12, 'filled', 'k' );
hold on;
XLim = xlim;
YLim = ylim;
% FillBetweenLines( XLim, XLim / UB95, XLim / LB95 );
% scatter( 4 * x, 4 * yMod, 12, 'filled', 'k' );
plot( XLim, XLim * thetaMod, 'k:', 'LineWidth', 1 );
plot( XLim, XLim * thetaIVMod, 'k-', 'LineWidth', 1 );
plot( XLim, XLim * thetaMSMod, 'k--', 'LineWidth', 1 );
OnLeft = ismember( Labels, { '2008Q4', '2011Q4', '2012Q4', '2020Q2', '2022Q1', '2022Q3' } ); % '2022Q4', '2023Q1'
OnRight = ismember( Labels, { '2009Q1', '2009Q3', '2009Q4', '2015Q2', '2020Q1', '2021Q2', '2022Q2' } ); % '2008Q3', 
text( 4 * x( OnRight ) + 4 * 0.05, 4 * yMod( OnRight ), Labels( OnRight ), 'HorizontalAlignment', 'left', 'VerticalAlignment', 'middle' );
text( 4 * x( OnLeft ) - 4 * 0.05, 4 * yMod( OnLeft ), Labels( OnLeft ), 'HorizontalAlignment', 'right', 'VerticalAlignment', 'middle' );
xlim( XLim );
ylim( YLim );
% xlabel( '$x_t=\pi_t-\pi_t^*$ \textsf{(continuously-compounded annual rate)}', 'Interpreter', 'latex' );
% ylabel( '$y_t$ \textsf{(continuously-compounded annual rate)}', 'Interpreter', 'latex' );
set( gca, 'Box', 'on' );
saveas( gcf, 'QuarterlyMod.svg' );

% Repeat the last analysis with the simple annual approach.

Data = readmatrix( 'EstimatingTheta.xlsx', 'Sheet', 'AveragedToAnnual', 'Range', 'A77:C90' );

x = Data( :, 3 );
y = Data( :, 2 );
Labels = Data( :, 1 );

% [ ~, SEtheta, theta ] = hac( X, y, 'Intercept', false, 'Whiten', 1, 'Weights', 'PZ' );
% Ptheta = 2 * ( 1 - tcdf( theta / SEtheta, size( y, 1 ) - 1 ) );

[ theta, ~, ~, Ptheta ] = hacIV( x, x, y );

disp( 'Estimated theta from the simple annual exercise:' );
disp( theta );
disp( 'HAC P-value from the simple annual exercise:' );
disp( Ptheta );
disp( 'R^2 from the simple annual exercise:' );
disp( 1 - sum( ( y - x * theta ) .^ 2 ) ./ sum( y .* y ) );

figure;
scatter( x, y, 'filled', 'k' );
hold on;
OnLeft = ismember( Labels, [ 2020, 2011, 2018, 2021 ] );
OnRightSpecial = ismember( Labels, 2010 );
OnRight = ~( OnLeft | OnRightSpecial );
text( x( OnRightSpecial ) + 0.05, y( OnRightSpecial ) + 0.05, num2str( Labels( OnRightSpecial ) ), 'HorizontalAlignment', 'left', 'VerticalAlignment', 'middle' );
text( x( OnRight ) + 0.05, y( OnRight ), num2str( Labels( OnRight ) ), 'HorizontalAlignment', 'left', 'VerticalAlignment', 'middle' );
text( x( OnLeft ) - 0.05, y( OnLeft ), num2str( Labels( OnLeft ) ), 'HorizontalAlignment', 'right', 'VerticalAlignment', 'middle' );
XLim = xlim;
YLim = ylim;
plot( XLim, XLim * theta, 'k' );
xlim( XLim );
ylim( YLim );
set( gca, 'Box', 'on' );
saveas( gcf, 'Annual.svg' );



% Do SPF forecasts predict breakeven inflation?

Data = readmatrix( 'BreakevenInflationVsSurveyOfProfessionalForecasters.xlsx', 'Sheet', 'Calculations', 'Range', 'H2:I73' );

y = Data( :, 1 );
x = Data( :, 2 );

[ theta, var_theta, ~, Ptheta0, ~, ~, ~, ~, ~, Ptheta1 ] = hacIV( [ ones( size( x ) ), x ], [ ones( size( x ) ), x ], y, [ NaN; 1 ] );

disp( 'Results of predicting five-year breakeven inflation from five-year SPF inflation expectations (slope, standard error, p-value of == 0, p-value of == 1):' );
disp( [ theta( 2 ) sqrt( var_theta( 2, 2 ) ) Ptheta0( 2 ), Ptheta1 ] );

figure;
scatter( x, y, 12, 'filled', 'k' );
hold on;
XLim = xlim;
YLim = ylim;
plot( XLim, XLim * theta( 2 ) + theta( 1 ), 'k' );
xlabel( 'Five-year SPF inflation expectations (annual rate)' );
ylabel( 'Five-year breakeven inflation (annual rate)')
xlim( XLim );
ylim( YLim );
set( gca, 'Box', 'on' );
saveas( gcf, 'BreakevenInflationVsSPF.svg' );




% Does breakeven inflation forecast actual inflation?

Data = readmatrix( 'BreakevenInflationVsReality.xlsx', 'Sheet', 'T5YIEM', 'Range', 'D12:E199' );

x = Data( :, 1 );
y = Data( :, 2 );

[ theta, var_theta, ~, Ptheta ] = hacIV( [ ones( size( x ) ), x ], [ ones( size( x ) ), x ], y );

disp( 'Results of predicting five-year realised inflation from five-year breakeven inflation (slope, standard error, p-value):' );
disp( [ theta( 2 ) sqrt( var_theta( 2, 2 ) ) Ptheta( 2 ) ] );

x = diff( x );
y = diff( y );

[ theta, var_theta, ~, Ptheta ] = hacIV( x, x, y );

disp( 'Results of predicting changes in five-year realised inflation from changes in five-year breakeven inflation (slope, standard error, p-value):' );
disp( [ theta sqrt( var_theta ) Ptheta ] );

figure;
scatter( x, y, 12, 'filled', 'k' );
hold on;
XLim = xlim;
YLim = ylim;
plot( XLim, XLim * theta, 'k' );
xlabel( 'Change in five-year breakeven inflation (annual rate)' );
ylabel( 'Change in five-year realised inflation (annual rate)')
xlim( XLim );
ylim( YLim );
set( gca, 'Box', 'on' );
saveas( gcf, 'BreakevenInflationVsReality.svg' );




function [ A, B, C, D, Mean0, Cov0, StateType ] = ParameterFunction( Parameters )

    % "Hat" below is subscript 1 in the paper!
    % State vector: 1 epsilonHat, 2 epsilonStarHat, 3 PiHat, 4 PiStarHat, 5 PiStarInfinity, 6 Pi0, 7 IMR0LInvPi0, 8 Pi12, 9 IMR12LInvPi12, 10 Pi24, 11 IMR24LInvPi24, 12 Pi36, 13 IMR36LInvPi36, 14 Pi, 15 PiStar, 16-28 LagPiStar1-LagPIStar13
    % Shock vector: 1 epsilonHat, 2 epsilonStarHat, 3 epsilonInfinity, 4 epsilon0, 5 epsilon12, 6 epsilon24, 7 epsilon36
    % Observables vector: 1-40 PiStarAnnual, 41 Pi, 42 PiStarInfinity

    rho = @( s ) exp( -1 / ( 1 + s ) );
    scale = @( s ) ( 1 + s ) * rho( s ) ^ s;

    A = diag( [ 0, 0, 2 ./ ( 1 + exp( -Parameters( 1 ) ) ) - 1, 2 ./ ( 1 + exp( -Parameters( 2 ) ) ) - 1, 0.9999, rho( 0 ), rho( 0 ), rho( 12 ), rho( 12 ), rho( 24 ), rho( 24 ), rho( 36 ), rho( 36 ), 0, 0, zeros( 1, 13 ) ] );
    A( 3, 1 ) = Parameters( 3 );
    A( 4, 2 ) = Parameters( 4 );
    A( 15 : 28, 15 : 28 ) = diag( ones( 13, 1 ), -1 );
    
    B = zeros( 28, 7 );
    B( 1, 1 ) = 1;
    B( 2, 2 ) = 1;
    B( 3, 1 ) = exp( Parameters( 5 ) );
    B( 4, 2 ) = exp( Parameters( 6 ) );
    B( 5, 3 ) = exp( Parameters( 7 ) );
    B( 7, 4 ) = exp( Parameters( 8 ) ) / scale( 0 );
    B( 9, 5 ) = exp( Parameters( 8 ) ) / scale( 12 );
    B( 11, 6 ) = exp( Parameters( 8 ) ) / scale( 24 );
    B( 13, 7 ) = exp( Parameters( 8 ) ) / scale( 36 );

    M = eye( 28 ); % Left hand side matrix!
    M( 6, 7 ) = -1;
    M( 8, 9 ) = -1;
    M( 10, 11 ) = -1;
    M( 12, 13 ) = -1;
    M( 14, 3 ) = -1;
    % M( 14, 5 ) = -Parameters( 9 );
    M( 14, 15 ) = -1; % -( 1 - Parameters( 9 ) );
    M( 15, 4 ) = -1;
    M( 15, 5 ) = -1;
    M( 15, 6 ) = -1;
    M( 15, 8 ) = -1;
    M( 15, 10 ) = -1;
    M( 15, 12 ) = -1;

    A = M \ A;
    B = M \ B;

    C = zeros( 42, 28 );
    SelectPiStarAnnual0 = zeros( 1, 28 );
    SelectPiStarAnnual0( 1, 15 : 26 ) = 1;
    SelectPiStarAnnual1 = zeros( 1, 28 );
    SelectPiStarAnnual1( 1, 16 : 27 ) = 1;
    SelectPiStarAnnual2 = zeros( 1, 28 );
    SelectPiStarAnnual2( 1, 17 : 28 ) = 1;
    SelectPiStarAnnual = ( SelectPiStarAnnual0 + SelectPiStarAnnual1 + SelectPiStarAnnual2 ) / 3; % Observed PiStarAnnual is Q4 to Q4 so we need to average over the quarter.
    C( 1, : ) = SelectPiStarAnnual;
    Power = eye( 28 );
    for t = 2 : 40
        Power = A * Power;
        C( t, : ) = SelectPiStarAnnual * Power;
    end
    C( 41, 14 ) = 1;
    C( 42, 5 ) = 1;

    D = zeros( 42, 0 );

    Mean0 = zeros( 28, 1 );
    Mean0( [ 5, 14 : 28 ] ) = 2 / 12;

    Cov0 = [];

    StateType = zeros( 28, 1 );

end
