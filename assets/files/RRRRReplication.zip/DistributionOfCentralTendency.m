N = 19;
M = 1e8;
nu = 5;
Powers = 1 : ( nu - 1 );



T = sort( trnd( nu, N, M ) );

GetStatistics = @( Array ) mean( abs( Array.' ) .^ Powers ).';

Mean = GetStatistics( mean( T ) );
Median = GetStatistics( T( 10, :, : ) );
CentralTendencyMidPoint = GetStatistics( 0.5 * ( T( 4, :, : ) + T( 16, :, : ) ) );

Moment = Powers.';

Table = table( Moment, Mean, Median, CentralTendencyMidPoint );

disp( Table );

writetable( Table, 'DistributionOfCentralTendencyT.xlsx' );



T = sort( randn( N, M ) );

GetStatistics = @( Array ) mean( abs( Array.' ) .^ Powers ).';

Mean = GetStatistics( mean( T ) );
Median = GetStatistics( T( 10, :, : ) );
CentralTendencyMidPoint = GetStatistics( 0.5 * ( T( 4, :, : ) + T( 16, :, : ) ) );

Moment = Powers.';

Table = table( Moment, Mean, Median, CentralTendencyMidPoint );

disp( Table );

writetable( Table, 'DistributionOfCentralTendencyN.xlsx' );
